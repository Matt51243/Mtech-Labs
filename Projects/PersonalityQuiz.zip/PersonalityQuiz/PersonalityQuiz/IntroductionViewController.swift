//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by Matthew on 10/8/21.
//

import UIKit

class IntroductionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue) {
        
    }

}

